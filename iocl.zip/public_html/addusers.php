<?php
 include("config.php");
  if($_SERVER["REQUEST_METHOD"] == "POST") {
  
  // $db_handle = new DBController();

  $emp_id = $_POST['Employee'];
  $name = $_POST['name'];
  $location_code = $_POST['location'];
  $location_name = $_POST['location_name'];
  $department_code = $_POST['department'];
  $department_name = $_POST['department_name'];
  $grade = $_POST['grade'];
  $designation =$_POST['designation'];
  $password = $_POST['password'];
 
  $query = "INSERT INTO `users1`(`emp_id`,`name`,`location_code`,`location_name`,`department_code`,`department_name`,`grade`,`designation`,`password`) VALUES ('$emp_id','$name', '$location_code', '$location_name','$department_code','$department_name', '$grade','$designation', '$password')";

  $result = mysqli_query($db, $query);
  


  if(!empty($result)) {
    $success_message = "You have added the user successfully!"; 
     unset($_POST);
  } else {
    $error_message = "Problem in adding new user . Try Again!"; 
  }
}

?>


<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Add User</title>
  <link rel = "icon" type = "image/png" href = "https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png"> 
  
  <link rel='stylesheet' href='css/bootstrap.min.css'>
<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

      <link rel="stylesheet" href="css/style.css">
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>
  
</head>

<body>
  
    <div class="wrapper">
      <div class="clearfix content-heading">
          <img class="img-responsive float-left" src="https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png" alt="Logo">
      <h1>INDIAN OIL CORPORATION LIMITED</h1>
      </div>
    <form class="form-signin" action = "" method = "post"> 

    <?php if(!empty($success_message)) { ?> 
    <div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
    <?php } ?>
    <?php if(!empty($error_message)) { ?> 
    <div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
    <?php } ?>      
       
      <h3>Add User</h3>
      <input type="text" class="form-control" name="Employee" placeholder="Employee ID" required="" autofocus="" />
      <input type="text" class="form-control" name="name" placeholder="Name" required="" autofocus="" />
      <input type="text" class="form-control" name="location" placeholder="Location Code" required="" autofocus="" />
       <input type="text" class="form-control" name="location_name" placeholder="Location Name" required="" autofocus="" />
      <input type="text" class="form-control" name="department" placeholder="Department Code" required="" autofocus="" />
       <input type="text" class="form-control" name="department_name" placeholder="Department Name" required="" autofocus="" />
      
      <input type="text" class="form-control" name="grade" placeholder="Grade" required="" autofocus="" />
      <input type="text" class="form-control" name="designation" placeholder="Designation" required="" autofocus="" />
      <input type="password" class="form-control" name="password" placeholder="Password" required="" autofocus="" />
      <button class="btn btn-lg btn-success btn-block" type="submit">Add</button>
      <a href="welcomes.php" class="btn btn-lg btn-danger btn-block" type="submit" role="button">Exit</a>
    </form>
  </div>
  
  

</body>

</html>
