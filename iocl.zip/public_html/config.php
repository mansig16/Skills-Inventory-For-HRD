<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'id9867896_ioclskills');
   define('DB_PASSWORD', 'ioclskills');
   define('DB_DATABASE', 'id9867896_admin');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   
   #database connected
?>