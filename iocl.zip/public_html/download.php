<?php
include ('config.php');

#download excel script

if (isset($_POST["form"])) {
  $result = mysqli_query($db, 'select * from form');
    $filename =   "report.xls";;
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $isPrintHeader = false;
    if (! empty($result)) {
        foreach ($result as $row) {
            if (! $isPrintHeader) {
                echo implode("\t", array_keys($row)) . "\n";
                $isPrintHeader = true;
            }
            echo implode("\t", array_values($row)) . "\n";
        }
    }
    exit();
}


?>

<!--Project Title-Skills Inventory for HRD-->
<!--Designed and Developed by-Mansi Garg-->

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Download Report</title>
  <link rel = "icon" type = "image/png" href = "https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png">
  
  <link rel='stylesheet' href='css/bootstrap.min.css'>
<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

      <link rel="stylesheet" href="css/style.css">

  <script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>
    
    <style>
    footer {
	background-color: #454545;
	color: rgba(255,255,255,0.7);
	padding: 16px;
	position: absolute;
	width: 100%;
	bottom: 0;
	text-align:center;
}

</style>
</head>

<body>

    <div class="wrapper">
      <div class="clearfix content-heading">
          <img class="img-responsive float-left" src="https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png" alt="Logo">
      <h1>INDIAN OIL CORPORATION LIMITED</h1>
      </div>
    <form class="form-signin" action = "" method = "post"> 
    
  
      <button class="btn btn-lg btn-primary btn-block" type="submit" name="form">Download-REPORT</button> 
       
      <a href="welcome.php" class="btn btn-lg btn-danger btn-block" type="submit" role="button">Cancel</a>   
    </form>
  </div>
  
  <footer>
        <small>&copy; Copyright 2019, Indian Oil Corporation Limited</small>
        <!--<br><small> Made By Mansi Garg</small>-->
</footer>

</body>

</html>
