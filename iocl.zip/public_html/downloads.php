<?php include("config.php"); 

if(isset($_GET['id']))
{
    $location=$_GET['id'];

    #download left location feedbacks script
   
    $result = mysqli_query($db,"select emp_id,name from employee where location_name='$location' and emp_id NOT IN(select emp_id from employee NATURAL JOIN form where location_name ='$location'  UNION select emp_id from users1 where location_name='$location') ");
    $filename =   $location.".xls";;
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $isPrintHeader = false;
    if (! empty($result)) {
        foreach ($result as $row) {
            if (! $isPrintHeader) {
                echo implode("\t", array_keys($row)) . "\n";
                $isPrintHeader = true;
            }
            echo implode("\t", array_values($row)) . "\n";
        }
    }

    
    exit();
  

    
}

  ?>