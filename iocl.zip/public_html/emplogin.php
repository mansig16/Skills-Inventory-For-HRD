<?php
   include('usersession.php');

   $sw = mysqli_query($db,"select emp_id,name from employee where location_name = '$login_session1' and emp_id NOT IN(select emp_id from employee where emp_id='$user_check')  ");
   $storeArray = Array();
   $storeArrays = Array();
   while ($r = mysqli_fetch_array($sw, MYSQLI_ASSOC)) {
      $storeArray[] =  $r['emp_id']; 
      $storeArrays[] =  $r['name']; 
}



   if($_SERVER["REQUEST_METHOD"] == "POST") {
      
      
      $myid = mysqli_real_escape_string($db,$_POST['employee']);
      $ses = mysqli_query($db,"select location_name from employee where emp_id = '$myid' ");
      $rows = mysqli_fetch_array($ses,MYSQLI_ASSOC);
   
      $sess = mysqli_query($db,"select * from form where emp_id = '$myid' ");
      $rows1 = mysqli_fetch_array($sess,MYSQLI_ASSOC);


   #location of employee is matched with the location master
   #check for only one feedback
    $login_sessions1 = $rows['location_name'];
   
      if($login_sessions1==$login_session1)
      {
        
          if(empty($rows1))
          {
            $_SESSION['user'] = $myid;
           header("location: forms/form.php");
          }
          else
          {
            $error_message="Only one feedback is allowed";
          }
          
      }
      else
      {
        $error_message="Employee donot belong to your location";
       
      }
   }

?>