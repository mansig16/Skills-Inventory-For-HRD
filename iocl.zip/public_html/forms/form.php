<?php
   include('config.php');
   session_start();
   
   $id = $_SESSION['user'];
   
   $ses_sql = mysqli_query($db,"select name,designation,department_name,grade from employee where emp_id = '$id' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['name'];
    $login_session1 = $row['designation'];
    $login_session2 = $row['department_name'];
    $login_session3 = $row['grade'];
    
 if($_SERVER["REQUEST_METHOD"] == "POST") {
  
 
#behavioural skills
  $emp_id = $id;
  $b1 = $_POST['b1'];
  $b2 = $_POST['optradio2'];
  $b3 = $_POST['optradio3'];
  $b4 = $_POST['optradio4'];
  $b5 = $_POST['optradio5'];
  $b6 = $_POST['optradio6'];
//$b7 = $_POST['optradio7'];
  
#technical skills
  $t1 = $_POST['t1'];
  $t2 = $_POST['t2'];
//   $t3 = $_POST['t3'];
  $t3 = $_POST['optradio30'];
  $t4 = $_POST['optradio40'];
  $t51 = $_POST['optradio51'];
  $t52 = $_POST['optradio52'];
  $t53 = $_POST['optradio53'];
  $remarks = $_POST['remarks'];
  
  //$p7 =$_POST['optradio70'];
 
 #adding in the result database
  $query = "INSERT INTO `form` VALUES ('$emp_id','$t1','$t2','$t3','$t4','$t51','$t52','$t53','$b1', '$b2', '$b3','$b4','$b5', '$b6','$remarks')";

  $result = mysqli_query($db, $query);

  if(!empty($result)) {
    
    echo '<script type="text/javascript">'; 
    echo 'alert("You have submitted the FeedBack successfully! You will be redirected for another feedback soon");'; 
    echo 'window.location.href = "/employee.php";';
    echo '</script>';
  } else {
    $error_message = "Problem in submitting the feedback . Try Again!"; 
  }
}
   
   
?>


<!--Project Title-Skills Inventory for HRD-->
<!--Designed and Developed by-Mansi Garg-->


<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>QUESTIONNAIRE</title>
  <link rel = "icon" type = "image/png" href = "https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png"> 
  
  <link rel='stylesheet' href='css/bootstrap.min.css'>
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

  <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>

</head>

<body>
  
    <div class="wrapper">
      <div class="clearfix content-heading">
          
      <h1>SKILL INVENTORY QUESTIONNAIRE</h1>
      
      </div>
   
  
  <form class="form-signin" action = "" method = "post">
    <?php if(!empty($success_message)) { ?> 
    <div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
    <?php } ?>
    <?php if(!empty($error_message)) { ?> 
    <div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
    <?php } ?>
    <span><h5><u>Employee Id:</u> &nbsp <?php echo '<span id="star">'.$id.'</span>'; ?></h5></span>
      <span><h5><u>Name:</u>&nbsp<?php echo '<span id="star">'.$login_session.'</span>'; ?></h5></span>
      <span><h5><u>Designation:</u>&nbsp <?php echo '<span id="star">'.$login_session1.'</span>'; ?></h5></span>
      <span><h5><u>Department:</u>&nbsp<?php echo '<span id="star">'.$login_session2.'</span>'; ?></h5></span>
      <span><h5><u>Grade:</u> &nbsp<?php echo '<span id="star">'.$login_session3.'</span>'; ?></h5></span>
     

    <hr>
 
<h3><u>Technical Skills</u></h3>
    <div class="row tag ">
      <label> 1.Please mention recent outstanding contribution, of the officer, in his job domain, if any. If not a direct contribution, please mention, if the officer has proactively participated, in any, such event/accomplishment. Mention it in the space given below (Word Limit:100):</label>
  
 <input type="text" class="form-control" name="t1"   autofocus="" maxlength="100" required=""/>

  </div>

  <div class="row tag">
      
   <label>2. What is his/her expertise? Please mention his/her major accomplishment (Word Limit:100):</label>
<input type="text" class="form-control" name="t2" required=""  autofocus="" maxlength="100"/>

  </div>
  
  <div class="row tag">
      
    <label>3.How well versed is the officer in maintaining safety and SOPs at location?Please choose the option (by tick mark) you think, is the most suitable:</label>

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio30" required value="Bad">Bad
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="Average">Average
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="Excellent">Excellent
    </label>
  </div>
  <div class="row tag">
      
    <label>4.How well the Officer can troubleshoot common problems at location? Please choose the option (by tick mark) you think, is the most suitable:</label>

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio40" required value="Poor">Poor
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="Fair">Fair
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="Excellent">Excellent
    </label>
  </div>
  
  <div class="row tag">
      
    <label>5.How proficient is the officer in any of the metioned aspects? Please choose the option (by tick mark) you think, is the most suitable:</label>
  
  </div>
  
  <div class="row tag"><label>a. Mechanical Maintenance:
      <!--<div class="row tag">-->
    <label class="radio-inline"> 
      <input type="radio" name="optradio51" required value="N/A">N/A
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio51" value="Average">Average
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio51" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio51" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio51" value="Excellent">Excellent
    </label>
  <!--</div>-->
    </label></div>
    
      <div class="row tag"> <label>b. Electrical Maintenance:
      <!--<div class="row tag">-->
    <label class="radio-inline"> 
      <input type="radio" name="optradio52" required value="N/A">N/A
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio52" value="Average">Average
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio52" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio52" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio52" value="Excellent">Excellent
    </label>
  <!--</div>-->
    </label></div>
    
    <div class="row tag">
    <label>c. Instrumentation:
      <!--<div class="row tag">-->
    <label class="radio-inline"> 
      <input type="radio" name="optradio53" required value="N/A">N/A
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio53" value="Average">Average
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio53" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio53" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio53" value="Excellent">Excellent
    </label>
  <!--</div>-->
    </label>
</div>

  <br>

<h3><u>Behavioural Skills</u></h3>
     <div class="row tag">
      
   <label>1. Name a few behavioral skills, the officer is good at. Please quote, any event, projecting the accomplishment of the officer, using those skills. Please mention it in the space given below (Word Limit:150):</label>

<input type="text" class="form-control" name="b1" required="" autofocus="" maxlength="150"/>
  </div>

<div class="row tag">
    <label>2. How good, you find, the officer is as a team player? Please choose the option (by tick mark) you think, is the most suitable:</label>  
   

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio2" value="Bad" required >Bad
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="Average">Average
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="Excellent">Excellent
    </label>
  </div>


<div class="row tag">
      
   <label>3.How do you find customer centricity of the officer? Please choose the option (by tick mark) you think, is the most suitable:</label>

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio3" value="Low" required >Low
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="Basic">Basic
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="Demonstrating">Demonstrating
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="Proficient">Proficient
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="Excellent">Excellent
    </label>
  </div>

<div class="row tag">
   <label>4. Does he/she take pride in doing something new or things which improves systems? Please choose the option (by tick mark) you think, is the most suitable:</label> 

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio4" required value="Yes">Yes
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio4" value="No">No
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio4" value="Indifferent">Indifferent
    </label>
    
  </div>


<div class="row tag">
      
    <label>5.How do you find the temperament of the officer? Please choose the option (by tick mark) you think, is the most suitable:</label>

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio5" required value="Bad">Bad
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="Average">Average
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="Excellent">Excellent
    </label>
  </div>


<div class="row tag">
      <!--<div class="col-lg-9 tag">-->
   <lable> 6. How good he/she is, at learning new developments? Please choose the option (by tick mark) you think, is the most suitable:</label>

  </div>
  <div class="row tag">
    <label class="radio-inline"> 
      <input type="radio" name="optradio6" required value="Poor">Poor
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="Fair">Fair
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="Good">Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="Very Good">Very Good
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="Excellent">Excellent
    </label>
  </div>

<hr>

<p><b>Any additional Remarks (max 500 characters):</b></p>
<input type="text" class="form-control" name="remarks" placeholder="Remarks"  autofocus="" maxlength="500"/>
<hr>
<button class="btn btn-md btn-space btn-success d-block mx-auto" type="submit">Submit</button>

<a href="/employee.php" class="btn btn-md btn-space btn-danger d-block mx-auto" type="submit" role="button">Cancel</a>
  </form>


</body>

</html>
