<?php
   include('config.php');
   session_start();
   
   $id = $_SESSION['user'];
   
   $ses_sql = mysqli_query($db,"select name,designation,department_name,grade from employee where emp_id = '$id' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['name'];
    $login_session1 = $row['designation'];
    $login_session2 = $row['department_name'];
    $login_session3 = $row['grade'];
    
if($_SERVER["REQUEST_METHOD"] == "POST") {
  
  // $db_handle = new DBController();

  $emp_id = $id;
  $b1 = $_POST['optradio1'];
  $b2 = $_POST['optradio2'];
  $b3 = $_POST['optradio3'];
  $b4 = $_POST['optradio4'];
  $b5 = $_POST['optradio5'];
  $b6 = $_POST['optradio6'];
  $b7 =$_POST['optradio7'];
  

  $f1 = $_POST['optradio10'];
  $f2 = $_POST['optradio20'];
  $f3 = $_POST['optradio30'];
  $f4 = $_POST['optradio40'];
  $f5 = $_POST['optradio50'];
  $f6 = $_POST['optradio60'];
  $f7 =$_POST['optradio70'];
  $remarks =$_POST['remarks'];
 
  $query = "INSERT INTO `LPG` VALUES ('$emp_id','$f1','$f2','$f3','$f4','$f5','$f6','$f7','$b1', '$b2', '$b3','$b4','$b5', '$b6','$b7','$remarks')";

  $result = mysqli_query($db, $query);

  if(!empty($result)) {
    //  $success_message = "You have submitted the FeedBack successfully! You will be redirected for another feedback soon";
    // header("location:/trynew/employee.php");
    //  unset($_POST);
    echo '<script type="text/javascript">'; 
echo 'alert("You have submitted the FeedBack successfully! You will be redirected for another feedback soon");'; 
echo 'window.location.href = "/employee.php";';
echo '</script>';
  } else {
    $error_message = "Problem in submitting the feedback . Try Again!"; 
  }
}
   
   
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>QUESTIONNAIRE-LPG</title>
  <link rel = "icon" type = "image/png" href = "https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png"> 
  
  <link rel='stylesheet' href='css/bootstrap.min.css'>
<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

      <link rel="stylesheet" href="css/style.css">
<script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
    </script>
  
</head>

<body>
  
    <div class="wrapper">
      <div class="clearfix content-heading">
          
      <h1>SKILL INVENTORY QUESTIONNAIRE</h1>
      
      </div>
   
  
  <form class="form-signin" action = "" method = "post">

    <?php if(!empty($success_message)) { ?> 
    <div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
    <?php } ?>
    <?php if(!empty($error_message)) { ?> 
    <div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
    <?php } ?>
    <span><h5><u>Employee Id:</u> &nbsp <?php echo '<span id="star">'.$id.'</span>'; ?></h5></span>
      <span><h5><u>Name:</u>&nbsp<?php echo '<span id="star">'.$login_session.'</span>'; ?></h5></span>
      <span><h5><u>Designation:</u>&nbsp <?php echo '<span id="star">'.$login_session1.'</span>'; ?></h5></span>
      <span><h5><u>Department:</u>&nbsp<?php echo '<span id="star">'.$login_session2.'</span>'; ?></h5></span>
      <span><h5><u>Grade:</u> &nbsp<?php echo '<span id="star">'.$login_session3.'</span>'; ?></h5></span>
      <hr>
    <p>The Grading system is as follows-</p>
    <ol>
      <li><b>None/Low</b></li>
      <li><b>Basic</b></li>
      <li><b>Demonstrating</b></li>
      <li><b>Proficient</b></li>
      <li><b>Expert</b></li>
      

    </ol>

    <hr>

    <h3>Professional Skills</h3>


    <fieldset> <div class="row">
      <div class="col-lg-9 tag">
    1. How do you rate the officer on having LPG operations knowledge?



  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio10" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio10" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio10" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio10" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio10" value="5">5
    </label>
  </div>
</div></fieldset>
   


<div class="row">
      <div class="col-lg-9 tag">
   2. How well versed is the officer on plant safety and various statutory compliances?



  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio20" required value="1" >1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio20" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio20" value="3">3
    </label>
    <label class="radio-inline" >
      <input type="radio" name="optradio20" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio20" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    3. How well versed is the officer on various aspects of plant maintenance?



  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio30" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio30" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag"> 
    4. How well the officer can handle the problems related to mechanical breakdowns in LPG plant?



  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio40" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio40" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
   5. How well the officer can handle the problems related to electrical breakdowns in LPG plant?



  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio50" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio50" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio50" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio50" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio50" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    6. How well the officer can handle the problems related to Instrumentation breakdowns in LPG plant?


  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio60" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio60" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio60" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio60" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio60" value="5">5
    </label>
  </div>
</div>


<div class="row">
      <div class="col-lg-9 tag">
    7. How well versed is the officer on SOPs on various works being performed in a LPG plant?



  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio70" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio70" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio70" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio70" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio70" value="5">5
    </label>
  </div>
</div>
    <hr>
    <h3>Behavioural Skills</h3>
    <fieldset> <div class="row">
      <div class="col-lg-9 tag">
    1. How good is the officer in taking Leadership/Supervisory role ?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio1" value="1" required>1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio1" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio1" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio1" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio1" value="5">5
    </label>
  </div>
</div></fieldset>
   


<div class="row">
      <div class="col-lg-9 tag">
   2. How good is the officer in extending customer service?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio2" value="1" required >1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio2" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    3. How good are the communication skills of the officer?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio3" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio3" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    4. How well versed is the officer on Industry knowledge?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio4" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio4" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio4" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio4" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio4" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    5. How well the officer can analyse the business of corporation?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio5" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio5" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    6. How will you rate the officer's professional conduct at workplace?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio6" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio6" value="5">5
    </label>
  </div>
</div>

<div class="row">
      <div class="col-lg-9 tag">
    7. How will you rate the officer as team player?

  </div>
  <div class="col-lg-3">
    <label class="radio-inline"> 
      <input type="radio" name="optradio7" required value="1">1
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio7" value="2">2
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio7" value="3">3
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio7" value="4">4 
    </label>
    <label class="radio-inline">
      <input type="radio" name="optradio7" value="5">5
    </label>
  </div>
</div>




<hr>

<p><b>Any additional Remarks (max 500 characters):</b></p>
<input type="text" class="form-control" name="remarks" placeholder="Remarks"  autofocus="" maxlength="500" />
<hr>

<button class="btn btn-md btn-space btn-success d-block mx-auto" type="submit">Submit</button>

<a href="/employee.php" class="btn btn-md btn-space btn-danger d-block mx-auto" type="submit" role="button">Cancel</a>
  
  
  </form>
  

</body>

</html>
