<?php
   session_start();
   
   #user session starts
   
   if(session_destroy()) {
       
       #user session destry and home page will open
      header("Location: home.php");
   }
?>