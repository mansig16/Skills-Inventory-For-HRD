<?php 
include("config.php"); 
	

#script to show the track of employees left for feedback

$arr = array("LPG","Aviation","Operations","Pipeline","CONTRACT");
echo "<table ><br />";
echo "<tr>";
echo "<th>Locations</th>";

echo "<th>Pending Actions</th>";
echo "<th>For more Details</th>";

echo "</tr>";

	 $sw = mysqli_query($db,"select location_name from locations");
$storeArray = Array();
while ($r = mysqli_fetch_array($sw, MYSQLI_ASSOC)) {
    $storeArray[] =  $r['location_name']; 
     
}
	foreach ($storeArray as &$value1) {
		$result=mysqli_query($db,"SELECT count(*) as total FROM employee NATURAL JOIN form WHERE location_name='$value1'");
        $data=mysqli_fetch_assoc($result);

        $results=mysqli_query($db,"SELECT count(*) as total1 FROM employee WHERE location_name='$value1'");
        $datas=mysqli_fetch_assoc($results);

        $final=$datas['total1']-$data['total']-1;

        echo "<tr>";
        echo "<td>".$value1."</td>";
        if($final==-1)
        {
	        $final=0;
        }
        echo "<td>".$final."</td>";
        echo "<td>".'<a href="downloads.php?id='.$value1.'">'."Click here!!".'</a>'."</td>";
        echo "</tr>";

	}
    

echo "</table>";

unset($value);
unset($value1);
?>