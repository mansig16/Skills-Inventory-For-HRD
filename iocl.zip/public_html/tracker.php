<!--Project Title-Skills Inventory for HRD-->
<!--Designed and Developed by-Mansi Garg-->


<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Progress Tracker</title>
  <link rel = "icon" type = "image/png" href = "https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png"> 
  
  <link rel='stylesheet' href='css/bootstrap.min.css'>
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <link rel="stylesheet" href="css/style.css">

<style>
    footer {
	background-color: #454545;
	color: rgba(255,255,255,0.7);
	padding: 16px;
	position: relative;
	width: 100%;
	bottom: 0;
	text-align:center;
}

</style>
 
</head>


<body>
  
    <div class="wrapper">
      <div class="clearfix content-heading">
          <img class="img-responsive float-left" src="https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png" alt="Logo">
      <h1>INDIAN OIL CORPORATION LIMITED</h1>
      </div>
    <div class="form-signin">       
       <h3>PENDING FORMS</h3>
      
<?php 
	include("track.php");
 ?>

      
<a href="welcome.php" class="btn btn-lg btn-danger btn-block" type="submit" role="button">Exit</a>
    </div>
  </div>
  
  <footer>
        <small>&copy; Copyright 2019, Indian Oil Corporation Limited</small>
        <!--<br><small> Made By Mansi Garg</small>-->
</footer>
  
</body>

</html>