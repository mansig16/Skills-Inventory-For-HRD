<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myid = mysqli_real_escape_string($db,$_POST['employee']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT * FROM users1 WHERE emp_id = '$myid' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row

      if($count == 1) {

         $_SESSION['login_user'] = $myid;
         
         header("location: employee.php");
      }else {
         $error = "Your Login ID or Password is invalid";
      }
   }
?>

<!--Project Title-Skills Inventory for HRD-->
<!--Designed and Developed by-Mansi Garg-->

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>User Login</title>
  <link rel = "icon" type = "image/png" href = "https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png">
  
  <link rel='stylesheet' href='css/bootstrap.min.css'>
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">

      <link rel="stylesheet" href="css/style.css">
  <script type="text/javascript">
        function preventBack() { window.history.forward(); }
        setTimeout("preventBack()", 0);
        window.onunload = function () { null };
  </script>
  <style>
    footer {
	background-color: #454545;
	color: rgba(255,255,255,0.7);
	padding: 16px;
	position: relative;
	width: 100%;
	bottom: 0;
	text-align:center;
}

</style>
</head>

<body>

    <div class="wrapper">
      <div class="clearfix content-heading">
          <img class="img-responsive float-left" src="https://seeklogo.com/images/I/indian-oil-logo-CD98A381FE-seeklogo.com.png" alt="Logo">
      <h1>INDIAN OIL CORPORATION LIMITED</h1>
      </div>
    <form class="form-signin" action = "" method = "post">       
      <h3>Please login</h3>
      <?php if(!empty($error)) { ?> 
    <div class="error-message"><?php if(isset($error)) echo $error; ?></div>
    <?php } ?> 
      <input type="text" class="form-control" name="employee" placeholder="Employee ID" required="" autofocus="" />
      <input id="psw" type="password" class="form-control" name="password" placeholder="Password" required=""/>      
      <input type="checkbox" onclick="myFunction()">Show Password
      <button class="btn btn-lg btn-success btn-block" type="submit">Login</button>
      <a href="index.php" class="btn btn-lg btn-danger btn-block" type="submit" role="button">Exit</a>   

      
    </form>
  </div>
  <footer>
        <small>&copy; Copyright 2019, Indian Oil Corporation Limited</small>
        <!--<br><small> Made By Mansi Garg</small>-->
</footer>
  
  <script>


function myFunction() {
  var x = document.getElementById("psw");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

</body>

</html>
