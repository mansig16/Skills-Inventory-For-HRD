<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($db,"select name,location_name,designation from users1 where emp_id = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['name'];
   $login_session1 = $row['location_name'];
   $login_session2 = $row['designation'];
   
   if(!isset($_SESSION['login_user'])){
      header("location:userlogin.php");
      die();
   }
?>